def get_hook_dirs():
    return __path__

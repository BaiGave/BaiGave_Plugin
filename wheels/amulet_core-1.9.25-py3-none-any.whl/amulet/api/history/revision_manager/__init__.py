from .ram import RAMRevisionManager
from .disk import DBRevisionManager
